#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
#parse("File Header.java")
class ${NAME}{
    @TypeConverter
    fun fromString(value: String): List<${Model}> {
        val listType = object : TypeToken<List<${Model}>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromList(list: List<${Model}>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}