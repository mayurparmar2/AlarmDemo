
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class ${NAME}(
    val m${Model}: List<${Model}>,
    val myCallback: (m${Model}: ${Model}) -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun getItemViewType(position: Int): Int {
        return when (mLiveIpo[position].mainLineType) {
            0 -> Utils.${Layout1}
            1 -> Utils.${Layout2}
            else -> {
                Utils.${Layout1}
            }
        }
    }
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder  {
        val inflater = LayoutInflater.from(viewGroup.getContext())
        return when (viewType) {
            Utils.${Layout1} -> {
                val binding = ${Layout1}Binding.inflate(inflater, viewGroup, false)
                LiveViewHolder(binding)
            }
            Utils.${Layout2} -> {
                val binding = ${Layout2}Binding.inflate(inflater, viewGroup, false)
                UpcomingHolder(binding)
            }
            else -> {
                throw IllegalArgumentException("Invalid view type")
            }
        }
    }
    override fun getItemCount() = mLiveIpo.size
    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        return when (viewHolder) {
            is ${Layout1}Holder -> {
                viewHolder.bind(mLiveIpo[position])
            }
            is ${Layout2}Holder -> {
                viewHolder.bind(mLiveIpo[position])
            }else -> {}
        }
    }




    inner class ${Layout1}Holder(val binding: ${Layout1}Binding) :
        RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("SetTextI18n")
        fun bind(m${Model}: ${Model}) {
            mLiveIpo.apply {
                
            }
            itemView.setOnClickListener {
                myCallback(mLiveIpo)
            }

        }
    }
    inner class ${Layout2}Holder(val binding: ${Layout2}Binding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(mLiveIpo: ${Model}) {
            mLiveIpo.apply {
               
            }
            itemView.setOnClickListener {
                myCallback(mLiveIpo)
            }
        }
    }

//    private var ipoList: List<DeailsIpo> = mLiveIpo.toList()
//    private var mLiveIpo: List<DeailsIpo> = ipoList
//    fun filter(query: String) {
//        mLiveIpo = if (query.isEmpty()) {
//            ipoList // If query is empty, show the full list
//        } else {
//            ipoList.filter {
//                it.companyName!!.contains(query, ignoreCase = true)
//            } // Filter based on company name or other attributes
//        }
//        notifyDataSetChanged() // Notify the adapter about the data change
//    }
}