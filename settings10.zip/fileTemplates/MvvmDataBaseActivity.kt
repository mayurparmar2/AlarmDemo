#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
import android.os.Bundle
#parse("File Header.java")
class ${NAME}: AppCompatActivity() {
    lateinit var viewModal: ${Model}ViewModel
    lateinit var dataAdapter: DataAdapter

    val m${Model}List = mutableListOf<${Model}>()

    public override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
        setContentView(R.layout.${NAME}_main)

        viewModal = ViewModelProvider(
                this,
                ViewModelProvider.AndroidViewModelFactory.getInstance(application)
        ).get(${Model}ViewModel::class.java)
        
        dataAdapter = DataAdapter(application,m${Model}List, DataAdapter.On${Model}ItemClick {
            startActivity(Intent(this@${NAME},ViewActivity::class.java))
        })
        recycleView.adapter = dataAdapter

        saveBtn.setOnClickListener {
            viewModal.add${Model}(${Model}(saveBtn.text.toString()))
        }
        viewModal.all${Model}.observe(this, Observer {
            it?.let {
                m${Model}List.clear()
                m${Model}List.addAll(it)
                dataAdapter.notifyDataSetChanged()
            }
        })
    }
}