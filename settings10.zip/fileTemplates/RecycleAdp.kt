
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import ${PACKAGE_NAME}.R

class ${NAME}(private val m${Model}: List<${Model}>,val myCallback: (position: Int) -> Unit) : RecyclerView.Adapter<${NAME}.ViewHolder>() {
   
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(viewGroup.getContext())
        val binding = ${NAME}Binding.inflate(inflater, viewGroup, false)
        return ViewHolder(binding)
        
     //   val view = LayoutInflater.from(viewGroup.context).inflate(R.layout.${NAME}_item, viewGroup, false)
       // return ViewHolder(view)
    }
    override fun getItemCount() = m${Model}.size
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        viewHolder.bind(m${Model}[position])
    }
    inner class ViewHolder(val binding: ${NAME}Binding): RecyclerView.ViewHolder(binding.root) {
        fun bind(m${Model}: ${Model}) {
            itemView.setOnClickListener {
                myCallback(adapterPosition)
            }

        }
    }
    //private var currentFilterOption: FilterOption? = null
    //private var m${Model}Filtered: List<${Model}> = m${Model}.toList()
    //  fun applyFilter(filterOption: FilterOption) {
    //    currentFilterOption = filterOption
    //      when (filterOption) {
    //          FilterOption.SHORTBY_NAME -> {
    //              m${Model}Filtered = m${Model}.sortedBy { it.departureTime }
    //          }
    //      }
    //      notifyDataSetChanged()
    //  }
    // enum class FilterOption {
    //      SHORTBY_NAME
    //  }
}
