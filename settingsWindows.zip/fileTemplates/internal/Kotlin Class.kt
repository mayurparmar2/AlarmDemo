#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
class ${NAME} private constructor() {
    companion object {
        val instance:${NAME} get() = ${NAME}()
    }
}